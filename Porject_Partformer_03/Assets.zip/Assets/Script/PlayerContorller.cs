using System.Collections;
using System.Collections.Generic;
using UnityEditor.SearchService;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerContorller : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 5f;
    public Transform groundCheck;
    public LayerMask groundLayer;

    private Rigidbody2D rb;
    private Animator pAni;
    private bool isGrounded;

    private bool isGiant = false;
    private float originalSpeed;

    public GameObject jumpItemImage;

    private bool isJumpBoosted = false;
    private float originalJumpForce;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        pAni = GetComponent<Animator>();
        originalSpeed = moveSpeed;
        originalJumpForce = jumpForce;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Respawn"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        if (collision.CompareTag("Finish"))
        {
            collision.GetComponent<LevelObject>().MoveToNextLevel();
        }

        if (collision.CompareTag("Enemy"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        if (collision.CompareTag("Item"))
        {
            Destroy(collision.gameObject);
            StartCoroutine(SpeedBoostCoroutine());
        }

        if (collision.CompareTag("Jump Item"))
        {
            isJumpBoosted = true;
            jumpItemImage.SetActive(true);
            jumpForce = 8f;
            Destroy(collision.gameObject);
            StartCoroutine(JumpBoostCoroutine());
        }
    }

    private void Update()
    {
        float moveInput = Input.GetAxisRaw("Horizontal");
        rb.velocity = new Vector2(moveInput * moveSpeed, rb.velocity.y);

        if (isGiant)
        {
            if (moveInput < 0)
                transform.localScale = new Vector3(2f, 2f, 2f);

            if (moveInput > 0)
                transform.localScale = new Vector3(-2f, 2f, 1f);
        }
        else
        {
            if (moveInput < 0)
                transform.localScale = new Vector3(1f, 1f, 1f);

            if (moveInput > 0)
                transform.localScale = new Vector3(-1f, 1f, 1f);
        }

        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);

        if (isGrounded && Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            pAni.SetTrigger("JumpAction");
        }
    }

    private IEnumerator GiantModeCoroutine()
    {
        moveSpeed = 8f;
        yield return new WaitForSeconds(5f);
        moveSpeed = originalSpeed;
        isGiant = false;
    }

    private IEnumerator SpeedBoostCoroutine()
    {
        moveSpeed = 8f;
        yield return new WaitForSeconds(5f);
        moveSpeed = originalSpeed;
    }

    private IEnumerator JumpBoostCoroutine()
    {
        yield return new WaitForSeconds(5f);
        jumpForce = originalJumpForce;
        isJumpBoosted = false;
        jumpItemImage.SetActive(false);
    }
}